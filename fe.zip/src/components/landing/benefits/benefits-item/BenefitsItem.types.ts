export interface IParallaxBenefitItemProps {
  i18Nkey: string;
  img: string;
  imgAlt: string;
  justify: string;
}
