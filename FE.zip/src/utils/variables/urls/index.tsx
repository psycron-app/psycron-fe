export const IP_GEO_URL = 'https://api.ipgeolocation.io/ipgeo';

export const CONTACT_CENTER = 'ask@psycron.app';

export const ALL_COUNTRIES =
	'https://restcountries.com/v3.1/all?fields=name,translations,flag,cca2,idd,currencies,timezones,region,subregion,languages';
