const languages = ['en', 'pt'];
import { generateSitemap } from 'react-sitemap-generator';
import publicRoutes from '@psycron/routes/PublicRoutes';

const routesWithLanguages = languages.flatMap((lang) =>
	publicRoutes.map((route) => ({
		...route,
		path: `/${lang}${route.path}`,
	}))
);

generateSitemap({
	url: 'https://psycron.app/',
	routes: routesWithLanguages,
	output: './public',
});
