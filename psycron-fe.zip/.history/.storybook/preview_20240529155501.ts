// .storybook/preview.js

import { Decorator } from '@storybook/react';
import { Global, css } from '@emotion/react';

const GlobalStyle = () => (
  <Global
    styles={css`
      body {
        font-family: 'Inter, sans-serif';
      }
    `}
  />
);

addDecorator((storyFn) => (
  <>
    <GlobalStyle />
    {storyFn()}
  </>
));
