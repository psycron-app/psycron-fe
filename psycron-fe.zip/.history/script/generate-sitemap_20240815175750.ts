import { writeFileSync } from 'fs';
import Sitemap from 'sitemap-ts';

import { UNSUBSCRIBE } from '../src/pages/urls';
import publicRoutes from '../src/routes/PublicRoutes';

interface Route {
	children?: Route[];
	element: JSX.Element;
	index?: boolean;
	path?: string;
}

const extractPaths = (
	routes: Route[],
	basePath = '',
	ignorePaths: string[] = []
): string[] => {
	const paths: string[] = [];

	routes.forEach((route) => {
		const fullPath = `${basePath}/${route.path || ''}`.replace(/\/+/g, '/');

		if (route.index) {
			paths.push(basePath);
		}

		if (route.path && !ignorePaths.includes(route.path)) {
			paths.push(fullPath);
		}

		if (route.children) {
			paths.push(...extractPaths(route.children, fullPath, ignorePaths));
		}
	});

	return paths;
};

const ignorePaths = [UNSUBSCRIBE];

const routes = extractPaths(publicRoutes, '', ignorePaths);

const uniqueRoutes = [...new Set(routes)];

console.log('Rotas extraídas:', uniqueRoutes);

const baseUrl = 'https://psycron.app';

const sitemap = new Sitemap({
	basePath: baseUrl,
	urls: uniqueRoutes.map((route) => ({
		url: route,
		changefreq: 'monthly',
		priority: 0.8,
	})),
});

const sitemapXml = sitemap.xml();
writeFileSync('./public/sitemap.xml', sitemapXml);
