export interface IEmptyStateProps {
    ariaLabel: string;
    img: string;
    isAppointment?: boolean;
    today: boolean;
}
