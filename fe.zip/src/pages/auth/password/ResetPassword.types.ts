export interface IEmailForm {
	email: string;
}

export interface IEmailResponse {
	message: string;
	status: string;
}
