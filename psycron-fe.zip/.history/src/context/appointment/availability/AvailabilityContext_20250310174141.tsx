import { createContext, useContext } from 'react';
import {
	getAvailabilityByDay,
	getTherapistLatestAvailability,
} from '@psycron/api/user';
import { getAppointmentDetailsBySlotId } from '@psycron/api/user/availability';
import type { IDateInfo } from '@psycron/api/user/index.types';
import { useUserDetails } from '@psycron/context/user/details/UserDetailsContext';
import { useInfiniteQuery, useQuery } from '@tanstack/react-query';

import type {
	AvailabilityContextType,
	AvailabilityProviderProps,
} from './AvailabilityContext.types';
import { mergeAvailabilityData } from './helpers';

const AvailabilityContext = createContext<AvailabilityContextType | undefined>(
	undefined
);

export const AvailabilityProvider = ({
	children,
}: AvailabilityProviderProps) => {
	const { therapistId } = useUserDetails();

	const { data, isLoading } = useQuery({
		queryKey: ['therapistAvailability', therapistId],
		queryFn: async ({ pageParam = 1 }) =>
			getTherapistLatestAvailability(therapistId, Number(pageParam)),
		enabled: !!therapistId,
		staleTime: 1000 * 60 * 5,
	});

	const isAvailabilityDatesEmpty =
		!data?.latestAvailability?.dates?.length || data?.totalPages === 0;

	return (
		<AvailabilityContext.Provider
			value={{
				availabilityData: data,
				availabilityDataIsLoading: isLoading,
				isAvailabilityDatesEmpty,
			}}
		>
			{children}
		</AvailabilityContext.Provider>
	);
};

export const useAvailability = (
	therapistId?: string,
	daySelectedFromCalendar?: IDateInfo,
	slotId?: string
) => {
	const context = useContext(AvailabilityContext);
	if (!context) {
		throw new Error(
			'useAvailability must be used within an AvailabilityProvider'
		);
	}

	const {
		data: dataFromSelectedDayRes,
		isLoading: isDataFromSelectedDayLoading,
		fetchNextPage,
		fetchPreviousPage,
		hasNextPage: rawHasNextPage,
	} = useInfiniteQuery({
		queryKey: [
			'availabilityByDay',
			therapistId,
			daySelectedFromCalendar?.date,
			daySelectedFromCalendar?.dateId,
		],
		queryFn: async ({ pageParam = 1 }) =>
			getAvailabilityByDay(therapistId, {
				date: daySelectedFromCalendar?.date,
				dateId: daySelectedFromCalendar?.dateId,
				page: Number(pageParam),
			}),
		enabled: !!therapistId && !!daySelectedFromCalendar?.dateId,
		initialPageParam: 1,
		getNextPageParam: (availabilityResponse, availabilityResponseArray) => {
			// O `availabilityResponse` é a última página carregada
			const lastPage = availabilityResponse;
			// `availabilityResponseArray` contém todas as páginas carregadas até agora
			const allPages = availabilityResponseArray.flatMap(
				(page) => page.latestAvailability.availabilityDates
			);

			// Se não houver `lastPage`, não carregamos mais nada
			if (!lastPage || !lastPage.latestAvailability) return undefined;

			// Total de páginas disponíveis na API
			const totalPages = lastPage.totalPages;
			// Última página carregada no frontend
			const currentPage = availabilityResponseArray.length;

			// Pegamos o último ID carregado na última página obtida
			const lastAvailableDateId =
				lastPage.latestAvailability.availabilityDates.at(-1)?._id;
			// Pegamos o último ID carregado considerando todas as páginas já carregadas
			const lastKnownDateId = allPages.at(-1)?._id;

			console.log('📌 Última página carregada:', lastPage);
			console.log(
				'📌 Último item carregado no chunk atual:',
				lastAvailableDateId
			);
			console.log(
				'📌 Último item carregado no dataset completo:',
				lastKnownDateId
			);
			console.log('📌 Total de páginas na API:', totalPages);
			console.log('📌 Páginas carregadas:', currentPage);

			// Só carregamos a próxima página se:
			// 1. Ainda não chegamos no total de páginas da API
			// 2. O último item carregado ainda não é o último disponível na API
			return currentPage < totalPages && lastAvailableDateId !== lastKnownDateId
				? currentPage + 1
				: undefined;
		},
		select: (data) => {
			return {
				pages: data.pages.map((page) => ({
					latestAvailability: {
						...page.latestAvailability,
						availabilityDates: page.latestAvailability?.availabilityDates ?? [],
						dates: page.latestAvailability?.dates ?? [],
					},
					totalPages: page.totalPages,
				})),
			};
		},

		placeholderData: (prev) => prev,
		staleTime: 1000 * 60 * 5,
	});
	console.log('>>>>>>>>>>>>> rawHasNextPage:', rawHasNextPage);

	const latestPage =
		dataFromSelectedDayRes?.pages?.[dataFromSelectedDayRes.pages.length - 1];

	const lastAvailableItem =
		latestPage?.latestAvailability?.availabilityDates?.at(-1);

	const lastAvailableDate = lastAvailableItem?.date;
	const lastAvailableDateIdFromPagination = lastAvailableItem?._id;

	const dataFromSelectedDay = mergeAvailabilityData(dataFromSelectedDayRes);
	// console.log('CONTEXT - ~ dataFromSelectedDay:', dataFromSelectedDay);

	const goToPreviousWeek = async () => {
		await fetchPreviousPage();
	};

	const goToNextWeek = async () => {
		try {
			console.log('CONTEXT - CLICKED NEXT 00');
			await fetchNextPage();
			console.log('CONTEXT - CLICKED NEXT 01');
		} catch (error) {
			console.error('❌ Erro ao carregar a próxima semana:', error);
		}
	};

	const availabilityDayId = daySelectedFromCalendar?.dateId;

	const lastDatesArrayItem =
		dataFromSelectedDay?.latestAvailability.dates?.at(-1);

	const hasNextPage =
		lastDatesArrayItem?.dateId !== lastAvailableDateIdFromPagination;

	console.log('00 ----- lastDatesArrayItem:', lastDatesArrayItem?.dateId);
	console.log(
		'01 ---- lastAvailableDateIdFromPagination:',
		lastAvailableDateIdFromPagination
	);
	console.log('02 ------ hasNextPage?:', hasNextPage);

	const {
		data: appointmentDetailsBySlotId,
		isLoading: isAppointmentDetailsBySlotIdLoading,
	} = useQuery({
		queryKey: ['getAppointmentDetailsBySlotId', availabilityDayId],
		queryFn: () =>
			getAppointmentDetailsBySlotId(therapistId, availabilityDayId, slotId),
		enabled: !!therapistId && !!slotId,
		retry: false,
		staleTime: 1000 * 60 * 5,
	});

	return {
		...context,
		dataFromSelectedDay,
		isDataFromSelectedDayLoading,
		hasNextPage,
		hasPreviousPage:
			dataFromSelectedDay?.latestAvailability?.availabilityDates?.length > 1,
		goToPreviousWeek,
		goToNextWeek,
		lastAvailableDate,
		lastAvailableDateIdFromPagination,
		appointmentDetailsBySlotId,
		isAppointmentDetailsBySlotIdLoading,
	};
};
