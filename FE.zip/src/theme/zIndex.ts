export const zIndexBase = 9999;
export const zIndexHover = 100;
export const zIndexPopover = zIndexBase + 1;
export const zIndexBg = -1;
export const zIndexTableHead = 20;
