import { createContext } from 'react';
import { useContext } from 'react';
import { getTherapistLatestAvailability } from '@psycron/api/user';
import { getAvailabilityByDay } from '@psycron/api/user';
import { getAppointmentDetailsBySlotId } from '@psycron/api/user/availability';
import type { IDateInfo } from '@psycron/api/user/index.types';
import { useUserDetails } from '@psycron/context/user/details/UserDetailsContext';
import { useInfiniteQuery, useQuery } from '@tanstack/react-query';

import type {
	AvailabilityContextType,
	AvailabilityProviderProps,
} from './AvailabilityContext.types';

const AvailabilityContext = createContext<AvailabilityContextType | undefined>(
	undefined
);

export const AvailabilityProvider = ({
	children,
}: AvailabilityProviderProps) => {
	const { therapistId } = useUserDetails();

	const { data, isLoading } = useQuery({
		queryKey: ['therapistAvailability', therapistId],
		queryFn: async () => getTherapistLatestAvailability(therapistId),
		enabled: !!therapistId,
		staleTime: 1000 * 60 * 5,
	});

	return (
		<AvailabilityContext.Provider
			value={{
				availabilityData: data,
				availabilityDataIsLoading: isLoading,
				isAvailabilityDatesEmpty: data?.isEmpty,
				firstDate: data?.firstDate,
				lastDate: data?.lastDate,
				totalPages: data?.totalPages,
			}}
		>
			{children}
		</AvailabilityContext.Provider>
	);
};

export const useAvailability = (
	initialDaySelected?: IDateInfo,
	slotId?: string
) => {
	console.log('🚀 ~ initialDaySelected:', initialDaySelected);
	const context = useContext(AvailabilityContext);
	if (!context) {
		throw new Error(
			'useAvailability must be used within an AvailabilityProvider'
		);
	}

	const { therapistId } = useUserDetails();

	const {
		data: dataFromSelectedDayRes,
		isLoading: isDataFromSelectedDayLoading,
		fetchNextPage,
		fetchPreviousPage,
		hasNextPage,
		hasPreviousPage,
	} = useInfiniteQuery({
		queryKey: ['availabilityByDay', therapistId, initialDaySelected?.dateId],
		queryFn: async ({ pageParam = null }) => {
			return getAvailabilityByDay(therapistId, {
				dateId: initialDaySelected?.dateId,
				cursor: pageParam,
			});
		},
		enabled: !!therapistId && !!initialDaySelected?.dateId,
		initialPageParam: null,
		getNextPageParam: (lastPage) => lastPage.nextCursor ?? null,
		getPreviousPageParam: (firstPage) => firstPage.previousCursor ?? null,
		placeholderData: (prev) => prev,
		staleTime: 1000 * 60 * 5,
	});

	const firstPage = dataFromSelectedDayRes?.pages?.[0];

	const latestPage = dataFromSelectedDayRes?.pages?.at(-1);

	const lastAvailableItem = latestPage?.availabilityDates?.at(-1);
	const lastAvailableDate = lastAvailableItem?.date ?? null;
	const lastAvailableDateIdFromPagination =
		lastAvailableItem?._id?.toString() ?? null;

	const consultationDuration =
		dataFromSelectedDayRes?.pages[0]?.consultationDuration;

	const goToPreviousWeek = async () => await fetchPreviousPage();
	const goToNextWeek = async () => await fetchNextPage();

	const availabilityDayId = initialDaySelected?.dateId ?? null;

	const {
		data: appointmentDetailsBySlotId,
		isLoading: isAppointmentDetailsBySlotIdLoading,
	} = useQuery({
		queryKey: ['getAppointmentDetailsBySlotId', availabilityDayId],
		queryFn: () =>
			getAppointmentDetailsBySlotId(therapistId, availabilityDayId, slotId),
		enabled: !!therapistId && !!slotId,
		retry: false,
		staleTime: 1000 * 60 * 5,
	});

	return {
		...context,
		dataFromSelectedDayRes,
		consultationDuration,
		isDataFromSelectedDayLoading,
		hasNextPage,
		hasPreviousPage,
		goToNextWeek,
		goToPreviousWeek,
		lastAvailableDate,
		lastAvailableDateIdFromPagination,
		appointmentDetailsBySlotId,
		isAppointmentDetailsBySlotIdLoading,
	};
};
