export interface AddPatientProps {
    shortButton: boolean;
}
