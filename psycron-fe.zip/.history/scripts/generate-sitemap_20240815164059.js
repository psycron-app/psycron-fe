"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fs_1 = require("fs");
var urls_1 = require("../src/pages/urls");
var PublicRoutes_1 = require("../src/routes/PublicRoutes");
var languages = ['en', 'pt'];
var extractPaths = function (routes, ignorePaths) {
    var paths = [];
    routes.forEach(function (route) {
        if (route.path && !ignorePaths.includes(route.path)) {
            paths.push(route.path);
        }
        if (route.children) {
            route.children.forEach(function (child) {
                if (child.path && !ignorePaths.includes(child.path)) {
                    paths.push("".concat(route.path ? route.path : '', "/").concat(child.path));
                }
                else if (child.index) {
                    paths.push(route.path ? route.path : '');
                }
            });
        }
    });
    return paths;
};
var ignorePaths = [urls_1.UNSUBSCRIBE];
var staticRoutes = extractPaths(PublicRoutes_1.default, ignorePaths);
var routesWithLanguages = languages.flatMap(function (lang) {
    return staticRoutes.map(function (route) { return "/".concat(lang).concat(route); });
});
var generateSitemapXML = function (routes, baseUrl) {
    var urlsetOpen = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
    var urlsetClose = '</urlset>';
    var urls = routes
        .map(function (route) {
        return "  <url>\n    <loc>".concat(baseUrl).concat(route, "</loc>\n    <changefreq>monthly</changefreq>\n    <priority>0.8</priority>\n  </url>");
    })
        .join('\n');
    return "".concat(urlsetOpen).concat(urls, "\n").concat(urlsetClose);
};
var sitemap = generateSitemapXML(routesWithLanguages, urls_1.DOMAIN);
(0, fs_1.writeFileSync)('./public/sitemap.xml', sitemap);
