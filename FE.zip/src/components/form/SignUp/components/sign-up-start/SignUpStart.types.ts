export type SignUpStartProps = {
	onContinueWithEmail: () => void;
};
