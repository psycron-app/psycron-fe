export const IP_GEO_KEY = import.meta.env.VITE_IP_GEO_KEY;
export const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
