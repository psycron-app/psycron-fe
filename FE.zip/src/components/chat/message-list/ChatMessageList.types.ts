import type { IChatMessage } from '../message/ChatMessage.types';

export interface IChatMessageList {
	messages: IChatMessage[];
}
