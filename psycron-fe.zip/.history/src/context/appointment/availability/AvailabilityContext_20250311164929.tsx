import { createContext, useContext } from 'react';
import {
	getAvailabilityByDay,
	getTherapistLatestAvailability,
} from '@psycron/api/user';
import { getAppointmentDetailsBySlotId } from '@psycron/api/user/availability';
import type { IDateInfo } from '@psycron/api/user/index.types';
import { useUserDetails } from '@psycron/context/user/details/UserDetailsContext';
import { useInfiniteQuery, useQuery } from '@tanstack/react-query';

import type {
	AvailabilityContextType,
	AvailabilityProviderProps,
	UseAvailabilityProps,
} from './AvailabilityContext.types';
import { mergeAvailabilityData } from './helpers';

const AvailabilityContext = createContext<AvailabilityContextType | undefined>(
	undefined
);

export const AvailabilityProvider = ({
	children,
}: AvailabilityProviderProps) => {
	const { therapistId } = useUserDetails();

	const { data, isLoading } = useQuery({
		queryKey: ['therapistAvailability', therapistId],
		queryFn: async () => getTherapistLatestAvailability(therapistId),
		enabled: !!therapistId,
		staleTime: 1000 * 60 * 5,
	});

	return (
		<AvailabilityContext.Provider
			value={{
				availabilityData: data,
				availabilityDataIsLoading: isLoading,
				isAvailabilityDatesEmpty: data.isEmpty,
				firstDate: data.firstDate,
				lastDate: data.lastDate,
				totalPages: data.totalPages,
			}}
		>
			{children}
		</AvailabilityContext.Provider>
	);
};

export const useAvailability = ({
	initialDaySelected,
	slotId,
}: UseAvailabilityProps) => {
	console.log('bbbbbbbbbb - initialDaySelected:', initialDaySelected);
	const context = useContext(AvailabilityContext);
	if (!context) {
		throw new Error(
			'useAvailability must be used within an AvailabilityProvider'
		);
	}

	const { therapistId } = useUserDetails();

	const {
		data: dataFromSelectedDayRes,
		isLoading: isDataFromSelectedDayLoading,
		fetchNextPage,
		fetchPreviousPage,
	} = useInfiniteQuery({
		queryKey: ['availabilityByDay', therapistId, initialDaySelected?.dateId],
		queryFn: async ({ pageParam = null }) => {
			return getAvailabilityByDay(therapistId, {
				dateId: initialDaySelected?.dateId,
				cursor: pageParam,
			});
		},
		enabled: !!therapistId && !!initialDaySelected?.dateId,
		initialPageParam: null,
		getNextPageParam: (lastPage) => lastPage.nextCursor ?? null, // 🔹 Usa `nextCursor` da API
		getPreviousPageParam: (firstPage) => firstPage.previousCursor ?? null, // 🔹 Usa `previousCursor` da API
		select: (data) => ({
			pages: data.pages.map((page) => ({
				availabilityDates: page.availabilityDates ?? [],
				totalItems: page.totalItems,
			})),
		}),

		placeholderData: (prev) => prev,
		staleTime: 1000 * 60 * 5,
	});

	const latestPage = dataFromSelectedDayRes.pages;
	dataFromSelectedDayRes?.pages?.[dataFromSelectedDayRes.pages.length - 1];

	const lastAvailableItem = dataFromSelectedDayRes.pages;

	const lastAvailableDate = lastAvailableItem?.date;
	const lastAvailableDateIdFromPagination = lastAvailableItem?._id;

	const dataFromSelectedDay = mergeAvailabilityData(dataFromSelectedDayRes);
	// console.log('CONTEXT - ~ dataFromSelectedDay:', dataFromSelectedDay);

	const goToPreviousWeek = async () => {
		await fetchPreviousPage();
	};

	const goToNextWeek = async () => {
		try {
			console.log('CONTEXT - CLICKED NEXT 00');
			await fetchNextPage();
			console.log('CONTEXT - CLICKED NEXT 01');
		} catch (error) {
			console.error('❌ Erro ao carregar a próxima semana:', error);
		}
	};

	const availabilityDayId = initialDaySelected?.dateId ?? null;

	const lastDatesArrayItem =
		dataFromSelectedDay?.latestAvailability.dates?.at(-1);

	const hasNextPage =
		lastDatesArrayItem?.dateId !== lastAvailableDateIdFromPagination;

	const {
		data: appointmentDetailsBySlotId,
		isLoading: isAppointmentDetailsBySlotIdLoading,
	} = useQuery({
		queryKey: ['getAppointmentDetailsBySlotId', availabilityDayId],
		queryFn: () =>
			getAppointmentDetailsBySlotId(therapistId, availabilityDayId, slotId),
		enabled: !!therapistId && !!slotId,
		retry: false,
		staleTime: 1000 * 60 * 5,
	});

	return {
		...context,
		dataFromSelectedDay,
		isDataFromSelectedDayLoading,
		hasNextPage,
		hasPreviousPage: false,
		goToPreviousWeek,
		goToNextWeek,
		lastAvailableDate,
		lastAvailableDateIdFromPagination,
		appointmentDetailsBySlotId,
		isAppointmentDetailsBySlotIdLoading,
	};
};
