// TimezoneContext.tsx
import type { ReactNode} from 'react';
import React, { createContext, useContext,useEffect, useState } from 'react';

interface TimezoneContextProps {
  timezone: string;
}

const TimezoneContext = createContext<TimezoneContextProps | undefined>(undefined);

export const TimezoneProvider = ( {children}: ReactNode ) => {
	const [timezone, setTimezone] = useState<string>('');

	useEffect(() => {
		const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
		setTimezone(tz);
	}, []);

	return (
		<TimezoneContext.Provider value={{ timezone }}>
			{children}
		</TimezoneContext.Provider>
	);
};

export const useTimezone = (): TimezoneContextProps => {
	const context = useContext(TimezoneContext);
	if (!context) {
		throw new Error('useTimezone must be used within a TimezoneProvider');
	}
	return context;
};
