export const ID_TOKEN = '_psyd';
export const REFRESH_TOKEN = '_psyrt';
export const THERAPIST_ID = '_psydui';
export const LATESTPATIENT_ID = '_psydpi';
export const AVAILABILITY_THREAD_ID = '_psth';
export const STORAGE_KIND_KEY = '_psy_persist';

/**
 * @deprecated ENCRYPTION_KEY removed for security (P1.3)
 * // export const ENCRYPTION_KEY = '_psyenk';
 */
