module.exports = {
  emotion: {
    sourceMap: true,
    autoLabel: 'always',
    labelFormat: '[local]',
    cssPropOptimization: true
  }
};
