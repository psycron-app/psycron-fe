import { AnimatedBackground } from '@psycron/components/animated-background/AnimatedBackground';

export const BlankPage = () => {
	return <AnimatedBackground />;
};
