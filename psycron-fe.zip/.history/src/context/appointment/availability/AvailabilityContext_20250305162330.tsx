import { createContext, useContext } from 'react';
import { getTherapistLatestAvailability } from '@psycron/api/user';
import { useUserDetails } from '@psycron/context/user/details/UserDetailsContext';
import { useInfiniteQuery } from '@tanstack/react-query';

import type {
	AvailabilityContextType,
	AvailabilityProviderProps,
} from './AvailabilityContext.types';

const AvailabilityContext = createContext<AvailabilityContextType | undefined>(
	undefined
);

export const AvailabilityProvider = ({
	children,
}: AvailabilityProviderProps) => {
	const { userDetails } = useUserDetails();
	const therapistId = userDetails?._id;

	const {
		data,
		isLoading,
		fetchNextPage,
		fetchPreviousPage,
		hasNextPage,
		hasPreviousPage,
	} = useInfiniteQuery({
		queryKey: ['therapistAvailability', therapistId],
		queryFn: async ({ pageParam = 1 }) =>
			getTherapistLatestAvailability(therapistId, pageParam),
		getNextPageParam: (lastPage, pages) =>
			pages.length < lastPage.totalPages ? pages.length + 1 : undefined,
		getPreviousPageParam: (_firstPage, allPages) =>
			allPages.length > 1 ? allPages.length - 1 : undefined,
		initialPageParam: 1,
		staleTime: 1000 * 60 * 5,
	});
	// Verifica se a disponibilidade está vazia
	const latestPage = data?.pages?.[data.pages.length - 1];
	const isAvailabilityEmpty =
		!latestPage?.latestAvailability?.availabilityDates?.length ||
		latestPage?.totalPages === 0;

	return (
		<AvailabilityContext.Provider
			value={{
				availabilityData: data?.pages?.[data.pages.length - 1],
				availabilityDataIsLoading: isLoading,
				fetchNextPage,
				fetchPreviousPage,
				hasNextPage: !!hasNextPage,
				hasPreviousPage: !!hasPreviousPage,
			}}
		>
			{children}
		</AvailabilityContext.Provider>
	);
};

export const useAvailability = () => {
	const context = useContext(AvailabilityContext);
	if (!context) {
		throw new Error(
			'useAvailability must be used within an AvailabilityProvider'
		);
	}
	return context;
};
