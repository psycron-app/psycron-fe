import type { Dispatch, ReactNode, SetStateAction } from 'react';
import type {
	IAvailabilityResponse,
	IDateInfo,
} from '@psycron/api/user/index.types';

export interface AvailabilityContextType {
	availabilityData?: IAvailabilityResponse;
	availabilityDataIsLoading: boolean;
	goToDate: (date: IDateInfo) => void;
	goToNextWeek: () => void;
	goToPreviousWeek: () => void;
	hasNextPage: boolean;
	hasPreviousPage: boolean;
	isAvailabilityEmpty: boolean;
	lastAvailableDate: string | Date;
	setSelectedDateState: Dispatch<SetStateAction<IDateInfo>>;
}

export interface AvailabilityProviderProps {
	children: ReactNode;
}
