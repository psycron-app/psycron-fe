const fs = require('file-system');
const path = require('path');

const storiesDir = path.join(__dirname, 'src');
const outputFile = path.join(__dirname, 'public', 'storiesList.json');

function getStories(dir, fileList = []) {
	const files = fs.readdirSync(dir);

	files.forEach((file) => {
		const filePath = path.join(dir, file);
		const stat = fs.statSync(filePath);

		if (stat.isDirectory()) {
			getStories(filePath, fileList);
		} else if (file.endsWith('.stories.tsx')) {
			fileList.push(filePath.replace(__dirname + '/src/', ''));
		}
	});

	return fileList;
}

const storiesList = getStories(storiesDir);

fs.writeFileSync(outputFile, JSON.stringify(storiesList, null, 2));

console.log('Stories list generated:', storiesList);
