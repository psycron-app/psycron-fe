import { Outlet } from 'react-router-dom';
import { EnvironmentBanner } from '@psycron/components/environment-banner/EnvironmentBanner';
import { Header } from '@psycron/components/header/Header';
import { useRuntimeEnv } from '@psycron/context/runtime/RuntimeEnvContext';

import {
	PublicLayoutContent,
	PublicLayoutWrapper,
} from './PublicLayout.styles';

export const PublicLayout = () => {
	const { isTestingEnv } = useRuntimeEnv();

	return (
		<>
			<PublicLayoutWrapper>
				<Header />
				<PublicLayoutContent>
					<EnvironmentBanner isVisible={isTestingEnv} />
					<Outlet />
				</PublicLayoutContent>
			</PublicLayoutWrapper>
		</>
	);
};
