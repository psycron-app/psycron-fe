export const IP_GEO_KEY = import.meta.env.VITE_IP_GEO_KEY;
export const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
export const ASSETS_CDN_URL = import.meta.env.VITE_ASSETS_CDN_URL;
export const PSYCRON_HOST = import.meta.env.VITE_PSYCRON_BASE_URL;
export const PSYCRON_BASE_API = import.meta.env.VITE_PSYCRON_BASE_API_URL;
