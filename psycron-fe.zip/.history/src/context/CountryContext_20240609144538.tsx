import type { Dispatch, FC, ReactNode, SetStateAction } from 'react';
import { createContext, useContext, useEffect, useState } from 'react';
import countryList from '@psycron/assets/countries/countries.json';
import { IP_GEO_KEY, IP_GEO_URL } from '@psycron/utils/variables';

import type { CountryDataFull, CountryDataSimple, UserGeoLocationContextType } from './CountryContext.types';


const DEFAULT_COUNTRY_DATA_SIMPLE: CountryDataSimple = {
	flag: './psycron-icon.svg',
	dialCode: '00',
};

export const UserGeoLocationContext = createContext<UserGeoLocationContextType>({
	countryData: DEFAULT_COUNTRY_DATA_SIMPLE,
});

export const UserGeoLocationProvider: FC<{ children: ReactNode }> = ({ children }) => {
	const [countryData, setCountryData] = useState<CountryDataFull | CountryDataSimple>(DEFAULT_COUNTRY_DATA_SIMPLE);


	const getUserCountryByIP = async () => {

		try {
			const response = await fetch(`${IP_GEO_URL}?apiKey=${IP_GEO_KEY}`);
            
		} catch (error) {
			console.log('🚀 ~ getUserCountryByIP ~ error:', error)
            
		}

	}

	const fetchUserCountry = async () => {
		try {
			const res = await fetch(`${IP_GEO_URL}?apiKey=${IP_GEO_KEY}`);
			const data = await res.json();
			console.log('🚀 ~ fetchUserCountry ~ data:', data)
			const userCountry = countryList.find(
				(c: Country) => c.code === data.country_code2
			);
			setCountry(userCountry || null);
		} catch (error) {
			console.log('Error', error);
		}
	};

	useEffect(() => {
		fetchUserCountry();
	}, []);

	return (
		<CountryContext.Provider value={{ country, setCountry }}>
			{children}
		</CountryContext.Provider>
	);
};

export const useUserGeolocation = (): UserGeoLocationContextType => {
	const context = useContext(CountryContext)
	if (context === undefined) {
		throw new Error('useCountry must be within a CountryProvider')
	} 
	return context
}