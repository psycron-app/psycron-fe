import type { TypographyProps } from '@mui/material';

export interface ITextProps extends TypographyProps {
  isFirstUpper?: boolean;
}
