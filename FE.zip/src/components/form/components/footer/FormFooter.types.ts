export type FormFooterProps = {
	disabled?: boolean;
};
