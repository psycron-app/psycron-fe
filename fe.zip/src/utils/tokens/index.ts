export const ID_TOKEN = '_psyd';
export const REFRESH_TOKEN = '_psyreft';
export const THERAPIST_ID = 'psydui';
export const LATESTPATIENT_ID = 'psydpi';
export const AVAILABILITY_THREAD_ID = '_psth';

/**
 * @deprecated ENCRYPTION_KEY removed for security (P1.3)
 * // export const ENCRYPTION_KEY = '_psyenk';
 */
