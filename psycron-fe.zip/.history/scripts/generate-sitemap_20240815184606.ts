import Sitemap from 'sitemap-ts';

import { UNSUBSCRIBE } from '../src/pages/urls';
import publicRoutes from '../src/routes/PublicRoutes';

// Função para extrair todos os caminhos das rotas
const extractPaths = (
	routes: { index?: boolean; path?: string }[]
): string[] => {
	return routes.map((route) => (route.index ? '/' : route.path || ''));
};

// Lista de rotas para ignorar
const ignorePaths = [UNSUBSCRIBE];

// Extrai os caminhos das rotas públicas
const routes = extractPaths(publicRoutes).filter(
	(route) => !ignorePaths.includes(route)
);

// Remove duplicatas caso existam
const uniqueRoutes = [...new Set(routes)];

console.log('Rotas extraídas:', uniqueRoutes);

// Gera o sitemap usando a função Sitemap
Sitemap({
	hostname: 'https://psycron.app',
	dynamicRoutes: uniqueRoutes,
	changefreq: 'monthly',
	priority: 0.8,
	outDir: './public',
	generateRobotsTxt: true,
	readable: true,
});

console.log('Sitemap gerado com sucesso!');
