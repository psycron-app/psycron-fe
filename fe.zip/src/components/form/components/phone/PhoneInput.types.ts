export interface PhoneInputProps {
	defaultValue?: string;
	disabled?: boolean;
	registerName: 'phone' | 'whatsapp';
	required: boolean;
}
