export type RouteParams = {
	locale?: string;
};
