export interface IContactInfoItemProps {
    label: string;
    value: string | null | undefined;
}
