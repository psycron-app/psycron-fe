import fs from 'file-system';
import { dirname,join } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const { readdirSync, statSync, writeFileSync } = fs;

const storiesDir = join(__dirname, 'src');
const outputFile = join(__dirname, 'public', 'storiesList.json');

function getStories(dir, fileList = []) {
	const files = readdirSync(dir);

	files.forEach((file) => {
		const filePath = join(dir, file);
		const stat = statSync(filePath);

		if (stat.isDirectory()) {
			getStories(filePath, fileList);
		} else if (file.endsWith('.stories.tsx')) {
			fileList.push(filePath.replace(`${__dirname}/src/`, ''));
		}
	});

	return fileList;
}

const storiesList = getStories(storiesDir);

writeFileSync(outputFile, JSON.stringify(storiesList, null, 2));

console.log('Stories list generated:', storiesList);
