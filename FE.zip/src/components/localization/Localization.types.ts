export interface ILocalization {
	hasMargin?: boolean;
}
