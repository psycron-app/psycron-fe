import type { ReactNode } from 'react';
import type { IAvailabilityResponse } from '@psycron/api/user/index.types';

export interface AvailabilityContextType {
	availabilityData?: IAvailabilityResponse;
	fetchNextPage: () => void;
	fetchPreviousPage: () => void;
	hasNextPage: boolean;
	hasPreviousPage: boolean;
	isLoading: boolean;
}

export interface AvailabilityProviderProps {
	children: ReactNode;
	therapistId?: string;
}
