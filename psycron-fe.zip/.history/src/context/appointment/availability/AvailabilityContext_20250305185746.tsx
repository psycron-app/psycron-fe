import { createContext, useContext } from 'react';
import { getTherapistLatestAvailability } from '@psycron/api/user';
import { useUserDetails } from '@psycron/context/user/details/UserDetailsContext';
import { useInfiniteQuery } from '@tanstack/react-query';

import type {
	AvailabilityContextType,
	AvailabilityProviderProps,
} from './AvailabilityContext.types';

const AvailabilityContext = createContext<AvailabilityContextType | undefined>(
	undefined
);

export const AvailabilityProvider = ({
	children,
}: AvailabilityProviderProps) => {
	const { userDetails } = useUserDetails();
	const therapistId = userDetails?._id;

	const {
		data,
		isLoading,
		fetchNextPage,
		fetchPreviousPage,
		hasNextPage,
		hasPreviousPage,
	} = useInfiniteQuery({
		queryKey: ['therapistAvailability', therapistId],
		queryFn: async ({ pageParam = 1 }) =>
			getTherapistLatestAvailability(therapistId, pageParam),
		enabled: !!therapistId,
		initialPageParam: 1,
		getNextPageParam: (lastPage, pages) => {
			const nextPage = pages.length + 1;
			return nextPage <= lastPage.totalPages ? nextPage : undefined;
		},
		getPreviousPageParam: (firstPage, pages, lastPageParam) => {
			if (lastPageParam <= 1) {
				console.log('⏹️ Already at the first page, cannot go back.');
				return undefined;
			}
			return lastPageParam - 1;
		},
		placeholderData: (prev) => prev,
		staleTime: 1000 * 60 * 5,
	});
	console.log('🚀 ~ hasPreviousPage:', hasPreviousPage);

	const latestPage = data?.pages?.[data.pages.length - 1];
	const isAvailabilityEmpty =
		!latestPage?.latestAvailability?.availabilityDates?.length ||
		latestPage?.totalPages === 0;

	return (
		<AvailabilityContext.Provider
			value={{
				availabilityData: data?.pages?.[data.pages.length - 1],
				availabilityDataIsLoading: isLoading,
				fetchNextPage,
				fetchPreviousPage,
				hasNextPage: !!hasNextPage,
				hasPreviousPage: !!hasPreviousPage,
				isAvailabilityEmpty,
			}}
		>
			{children}
		</AvailabilityContext.Provider>
	);
};

export const useAvailability = () => {
	const context = useContext(AvailabilityContext);
	if (!context) {
		throw new Error(
			'useAvailability must be used within an AvailabilityProvider'
		);
	}
	return context;
};
