import type { DividerProps } from '@mui/material';

export interface IDividerProps extends DividerProps {
  small?: boolean;
}