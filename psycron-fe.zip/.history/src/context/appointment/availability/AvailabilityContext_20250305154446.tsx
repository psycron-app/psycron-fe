import { createContext, useContext } from 'react';
import { getTherapistLatestAvailability } from '@psycron/api/user';
import { useInfiniteQuery } from '@tanstack/react-query';

import type { AvailabilityContextType } from './AvailabilityContext.types';

const AvailabilityContext = createContext<AvailabilityContextType | undefined>(
	undefined
);

export const AvailabilityProvider = ({
	therapistId,
	children,
}: {
	children: React.ReactNode;
	therapistId?: string;
}) => {
	const {
		data,
		isLoading,
		fetchNextPage,
		fetchPreviousPage,
		hasNextPage,
		hasPreviousPage,
	} = useInfiniteQuery({
		queryKey: ['therapistAvailability', therapistId],
		queryFn: async ({ pageParam = 1 }) =>
			getTherapistLatestAvailability(therapistId, pageParam),
		getNextPageParam: (lastPage, pages) =>
			pages.length < lastPage.totalPages ? pages.length + 1 : undefined,
		getPreviousPageParam: (firstPage, allPages) =>
			allPages.length > 1 ? allPages.length - 1 : undefined,
		initialPageParam: 1,
		staleTime: 1000 * 60 * 5,
	});

	return (
		<AvailabilityContext.Provider
			value={{
				availabilityData: data?.pages?.[data.pages.length - 1],
				isLoading,
				fetchNextPage,
				fetchPreviousPage,
				hasNextPage: !!hasNextPage,
				hasPreviousPage: !!hasPreviousPage,
			}}
		>
			{children}
		</AvailabilityContext.Provider>
	);
};

export const useAvailability = () => {
	const context = useContext(AvailabilityContext);
	if (!context) {
		throw new Error(
			'useAvailability must be used within an AvailabilityProvider'
		);
	}
	return context;
};
