import { readdirSync, statSync, writeFileSync } from 'file-system';
import { join } from 'path';

const storiesDir = join(__dirname, 'src');
const outputFile = join(__dirname, 'public', 'storiesList.json');

function getStories(dir, fileList = []) {
	const files = readdirSync(dir);

	files.forEach((file) => {
		const filePath = join(dir, file);
		const stat = statSync(filePath);

		if (stat.isDirectory()) {
			getStories(filePath, fileList);
		} else if (file.endsWith('.stories.tsx')) {
			fileList.push(filePath.replace(__dirname + '/src/', ''));
		}
	});

	return fileList;
}

const storiesList = getStories(storiesDir);

writeFileSync(outputFile, JSON.stringify(storiesList, null, 2));

console.log('Stories list generated:', storiesList);
