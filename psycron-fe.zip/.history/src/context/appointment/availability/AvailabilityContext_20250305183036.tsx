import { createContext, useContext } from 'react';
import { getTherapistLatestAvailability } from '@psycron/api/user';
import { useUserDetails } from '@psycron/context/user/details/UserDetailsContext';
import { useInfiniteQuery } from '@tanstack/react-query';

import type {
	AvailabilityContextType,
	AvailabilityProviderProps,
} from './AvailabilityContext.types';

const AvailabilityContext = createContext<AvailabilityContextType | undefined>(
	undefined
);

export const AvailabilityProvider = ({
	children,
}: AvailabilityProviderProps) => {
	const { userDetails } = useUserDetails();
	const therapistId = userDetails?._id;

	const {
		data,
		isLoading,
		fetchNextPage,
		fetchPreviousPage,
		hasNextPage,
		hasPreviousPage,
	} = useInfiniteQuery({
		queryKey: ['therapistAvailability', therapistId],
		queryFn: async ({ pageParam = 1 }) =>
			getTherapistLatestAvailability(therapistId, pageParam),
		enabled: !!therapistId,
		getNextPageParam: (lastPage, pages) =>
			pages.length < lastPage.totalPages ? pages.length + 1 : undefined,
		getPreviousPageParam: (firstPage, allPages) => {
			console.log('🚀 ~ firstPage:', firstPage);
			console.log('🚀 ~ allPages:', allPages);
			console.log('🚀 ~ allPages.length:', allPages.length);

			if (firstPage?.latestAvailability.availabilityDates.length === 1) {
				console.log('⏹️  First page reached, no previous page available.');
				return undefined;
			}

			// Retorna a página anterior corretamente
			const previousPage = allPages.length - 1;
			return previousPage > 1 ? previousPage : undefined;
		},
		initialPageParam: 1,
		staleTime: 1000 * 60 * 5,
	});

	const latestPage = data?.pages?.[data.pages.length - 1];
	const isAvailabilityEmpty =
		!latestPage?.latestAvailability?.availabilityDates?.length ||
		latestPage?.totalPages === 0;

	return (
		<AvailabilityContext.Provider
			value={{
				availabilityData: data?.pages?.[data.pages.length - 1],
				availabilityDataIsLoading: isLoading,
				fetchNextPage,
				fetchPreviousPage,
				hasNextPage: !!hasNextPage,
				hasPreviousPage: !!hasPreviousPage,
				isAvailabilityEmpty,
			}}
		>
			{children}
		</AvailabilityContext.Provider>
	);
};

export const useAvailability = () => {
	const context = useContext(AvailabilityContext);
	if (!context) {
		throw new Error(
			'useAvailability must be used within an AvailabilityProvider'
		);
	}
	return context;
};
