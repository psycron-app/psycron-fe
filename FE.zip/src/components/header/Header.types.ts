export interface IHeaderProps {
	hideLinks?: boolean;
}
