import { createContext, useContext, useEffect, useState } from 'react';
import {
	getAvailabilityByDay,
	getTherapistLatestAvailability,
} from '@psycron/api/user';
import { getAppointmentDetailsBySlotId } from '@psycron/api/user/availability';
import type { IDateInfo } from '@psycron/api/user/index.types';
import { useUserDetails } from '@psycron/context/user/details/UserDetailsContext';
import { useInfiniteQuery, useQuery } from '@tanstack/react-query';

import type {
	AvailabilityContextType,
	AvailabilityProviderProps,
} from './AvailabilityContext.types';
import { mergeAvailabilityData } from './helpers';

const AvailabilityContext = createContext<AvailabilityContextType | undefined>(
	undefined
);

export const AvailabilityProvider = ({
	children,
}: AvailabilityProviderProps) => {
	const { therapistId } = useUserDetails();

	const { data, isLoading } = useQuery({
		queryKey: ['therapistAvailability', therapistId],
		queryFn: async ({ pageParam = 1 }) =>
			getTherapistLatestAvailability(therapistId, Number(pageParam)),
		enabled: !!therapistId,
		staleTime: 1000 * 60 * 5,
	});

	const isAvailabilityDatesEmpty =
		!data?.latestAvailability?.dates?.length || data?.totalPages === 0;

	return (
		<AvailabilityContext.Provider
			value={{
				availabilityData: data,
				availabilityDataIsLoading: isLoading,
				isAvailabilityDatesEmpty,
			}}
		>
			{children}
		</AvailabilityContext.Provider>
	);
};

export const useAvailability = (
	daySelectedFromCalendar?: IDateInfo,
	slotId?: string
) => {
	const context = useContext(AvailabilityContext);
	if (!context) {
		throw new Error(
			'useAvailability must be used within an AvailabilityProvider'
		);
	}

	const { therapistId } = useUserDetails();
	const [dayFromCalendar, setDayFromCalendar] = useState<IDateInfo | null>(
		null
	);

	useEffect(() => {
		if (daySelectedFromCalendar) {
			setDayFromCalendar(daySelectedFromCalendar);
		}
	}, [daySelectedFromCalendar]);

	const {
		data: dataFromSelectedDayRes,
		isLoading: isDataFromSelectedDayLoading,
		fetchNextPage,
		fetchPreviousPage,
	} = useInfiniteQuery({
		queryKey: [
			'availabilityByDay',
			therapistId,
			daySelectedFromCalendar?.date,
			daySelectedFromCalendar?.dateId,
		],
		queryFn: async (dat) => {
			console.log('🚀 ~ queryFn: ~ dat:', dat);
			console.log('🚀 ~ queryFn: ~ pageParam:', dat.pageParam);
			return getAvailabilityByDay(therapistId, {
				date: daySelectedFromCalendar?.date,
				dateId: daySelectedFromCalendar?.dateId,
				page: dat.pageParam,
			});
		},

		enabled: !!therapistId && !!daySelectedFromCalendar?.dateId,
		initialPageParam: 1,
		getNextPageParam: (lastPage, allPages) => {
			if (!lastPage || !lastPage.totalPages) return undefined;

			const currentPage = allPages.length;
			const nextPage =
				currentPage + 1 <= lastPage.totalPages ? currentPage + 1 : undefined;

			console.log('➡️ Próxima página:', nextPage);

			return nextPage;
		},

		select: (data) => {
			return {
				pages: data.pages.map((page) => ({
					latestAvailability: {
						...page.latestAvailability,
						availabilityDates: page.latestAvailability?.availabilityDates ?? [],
						dates: page.latestAvailability?.dates ?? [],
					},
					totalPages: page.totalPages,
				})),
			};
		},

		placeholderData: (prev) => prev,
		staleTime: 1000 * 60 * 5,
	});

	const latestPage =
		dataFromSelectedDayRes?.pages?.[dataFromSelectedDayRes.pages.length - 1];

	const lastAvailableItem =
		latestPage?.latestAvailability?.availabilityDates?.at(-1);

	const lastAvailableDate = lastAvailableItem?.date;
	const lastAvailableDateIdFromPagination = lastAvailableItem?._id;

	const dataFromSelectedDay = mergeAvailabilityData(dataFromSelectedDayRes);
	// console.log('CONTEXT - ~ dataFromSelectedDay:', dataFromSelectedDay);

	const goToPreviousWeek = async () => {
		await fetchPreviousPage();
	};

	const goToNextWeek = async () => {
		try {
			console.log('CONTEXT - CLICKED NEXT 00');
			await fetchNextPage();
			console.log('CONTEXT - CLICKED NEXT 01');
		} catch (error) {
			console.error('❌ Erro ao carregar a próxima semana:', error);
		}
	};

	const availabilityDayId = daySelectedFromCalendar?.dateId;

	const lastDatesArrayItem =
		dataFromSelectedDay?.latestAvailability.dates?.at(-1);

	const hasNextPage =
		lastDatesArrayItem?.dateId !== lastAvailableDateIdFromPagination;

	const {
		data: appointmentDetailsBySlotId,
		isLoading: isAppointmentDetailsBySlotIdLoading,
	} = useQuery({
		queryKey: ['getAppointmentDetailsBySlotId', availabilityDayId],
		queryFn: () =>
			getAppointmentDetailsBySlotId(therapistId, availabilityDayId, slotId),
		enabled: !!therapistId && !!slotId,
		retry: false,
		staleTime: 1000 * 60 * 5,
	});

	return {
		...context,
		dataFromSelectedDay,
		isDataFromSelectedDayLoading,
		hasNextPage,
		hasPreviousPage:
			dataFromSelectedDay?.latestAvailability?.availabilityDates?.length > 1,
		goToPreviousWeek,
		goToNextWeek,
		lastAvailableDate,
		lastAvailableDateIdFromPagination,
		appointmentDetailsBySlotId,
		isAppointmentDetailsBySlotIdLoading,
	};
};
