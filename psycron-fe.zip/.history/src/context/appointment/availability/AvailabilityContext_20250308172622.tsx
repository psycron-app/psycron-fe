import { createContext, useContext, useState } from 'react';
import {
	getAvailabilityByDay,
	getTherapistLatestAvailability,
} from '@psycron/api/user';
import type {
	IAvailabilityResponse,
	IDateInfo,
} from '@psycron/api/user/index.types';
import { useUserDetails } from '@psycron/context/user/details/UserDetailsContext';
import { useInfiniteQuery } from '@tanstack/react-query';

import type {
	AvailabilityContextType,
	AvailabilityProviderProps,
} from './AvailabilityContext.types';

export const mergeAvailabilityData = (data?: {
	pages: IAvailabilityResponse[];
}): IAvailabilityResponse | undefined => {
	if (!data?.pages?.length) return undefined;

	return data.pages.reduce<IAvailabilityResponse | undefined>((acc, page) => {
		if (!acc) return page;
		return {
			...acc,
			latestAvailability: {
				...acc.latestAvailability,
				availabilityDates: [
					...(acc.latestAvailability?.availabilityDates ?? []),
					...(page.latestAvailability?.availabilityDates ?? []),
				],
				dates: [
					...(acc.latestAvailability?.dates ?? []),
					...(page.latestAvailability?.dates ?? []),
				],
			},
			totalPages: page.totalPages,
		};
	}, undefined);
};

const AvailabilityContext = createContext<AvailabilityContextType | undefined>(
	undefined
);

export const AvailabilityProvider = ({
	children,
}: AvailabilityProviderProps) => {
	const { userDetails } = useUserDetails();
	const therapistId = userDetails?._id;

	const [selectedDateState, setSelectedDateState] = useState<
		IDateInfo | undefined
	>(undefined);

	const { data, isLoading, fetchNextPage, fetchPreviousPage, hasNextPage } =
		useInfiniteQuery({
			queryKey: ['therapistAvailability', therapistId],
			queryFn: async ({ pageParam = 1 }) =>
				getTherapistLatestAvailability(therapistId, pageParam),
			enabled: !!therapistId || !selectedDateState,
			initialPageParam: 1,
			getNextPageParam: (lastPage, allPages) => {
				const nextPage = allPages.length + 1;
				return nextPage <= lastPage.totalPages ? nextPage : undefined;
			},
			getPreviousPageParam: (_firstPage, allPages) => {
				return allPages.length > 1 ? allPages.length - 1 : undefined;
			},
			select: (data) => {
				return {
					pages: data.pages.map((page) => ({
						...page,
						latestAvailability: {
							...page.latestAvailability,
							availabilityDates:
								page.latestAvailability?.availabilityDates ?? [],
						},
					})),
				};
			},
			placeholderData: (prev) => prev,
			staleTime: 1000 * 60 * 5,
		});

	const availabilityData: IAvailabilityResponse | undefined =
		mergeAvailabilityData(data);

	const isDateAlreadyLoaded =
		selectedDateState &&
		availabilityData?.latestAvailability?.availabilityDates?.some(
			({ date }) => date === selectedDateState?.date
		);

	const {
		data: dataByDay,
		isLoading: isLoadingByDay,
		fetchNextPage: fetchNextDayPage,
		hasNextPage: hasNextDayPage,
	} = useInfiniteQuery({
		queryKey: [
			'availabilityByDay',
			therapistId,
			selectedDateState?.date,
			selectedDateState?.dateId,
		],
		queryFn: async () =>
			getAvailabilityByDay(therapistId!, {
				date: selectedDateState!.date,
				dateId: selectedDateState!.dateId,
			}),
		enabled: !!therapistId && !!selectedDateState && !isDateAlreadyLoaded,
		initialPageParam: 1,
		getNextPageParam: (lastPage, allPages) => {
			const nextPage = allPages.length + 1;
			return nextPage <= lastPage.totalPages ? nextPage : undefined;
		},
		select: (data) => {
			return {
				pages: data.pages.map((page) => ({
					latestAvailability: {
						...page.latestAvailability,
						availabilityDates: page.latestAvailability?.availabilityDates ?? [],
						dates: page.latestAvailability?.dates ?? [],
					},
					totalPages: page.totalPages,
				})),
			};
		},

		placeholderData: (prev) => prev,
		staleTime: 1000 * 60 * 5,
	});

	const latestPage = data?.pages?.[data.pages.length - 1];
	const isAvailabilityEmpty =
		!latestPage?.latestAvailability?.availabilityDates?.length ||
		latestPage?.totalPages === 0;
	const lastAvailableDate =
		latestPage?.latestAvailability?.availabilityDates?.slice(-1)[0]?.date ?? '';

	const finalAvailabilityData = isDateAlreadyLoaded
		? availabilityData
		: mergeAvailabilityData(dataByDay);

	const goToPreviousWeek = async () => {
		await fetchPreviousPage();
	};

	const goToNextWeek = async () => {
		await fetchNextPage();
	};

	const goToDate = (dateInfo: IDateInfo) => {
		setSelectedDateState(dateInfo);
	};

	return (
		<AvailabilityContext.Provider
			value={{
				availabilityData: finalAvailabilityData,
				availabilityDataIsLoading: isLoading || isLoadingByDay,
				hasNextPage: !!hasNextPage || !!hasNextDayPage,
				hasPreviousPage: data?.pages?.length > 1,
				isAvailabilityEmpty,
				goToPreviousWeek,
				goToNextWeek,
				lastAvailableDate,
				goToDate,
			}}
		>
			{children}
		</AvailabilityContext.Provider>
	);
};

export const useAvailability = () => {
	const context = useContext(AvailabilityContext);
	if (!context) {
		throw new Error(
			'useAvailability must be used within an AvailabilityProvider'
		);
	}
	return context;
};
