import { Box, styled } from '@mui/material';

export const StyledProgressWrapper = styled(Box)`
    display: flex;
    align-items: center;
    width: 100%;
`;
