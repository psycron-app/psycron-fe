// .storybook/preview.tsx
import React, { useEffect } from 'react';
import i18n from '../src/i18n.ts';
import { ThemeProvider, CssBaseline } from '@mui/material';
import { BrowserRouter } from 'react-router-dom';

import theme from '../src/theme';

import { UserDetailsProvider } from '../src/context/user/UserDetailsContext';
import { UserGeoLocationProvider } from '../src/context/CountryContext';

const preview = {
	decorators: [
		(Story, context) => {
			useEffect(() => {
				// Verifica se não há deep link ativo e redireciona para a história desejada
				const url = new URL(window.location.href);
				const path = url.searchParams.get('path');

				if (!path) {
					// Redireciona para a introdução, substitua 'introduction--page' pelo ID da sua história
					window.location.href = '/?path=/story/getting-started--introduction';
				}
			}, []);
			return (
				<BrowserRouter>
					<ThemeProvider theme={theme}>
						<CssBaseline />
						<UserDetailsProvider>
							<UserGeoLocationProvider>
								<Story {...context} />
							</UserGeoLocationProvider>
						</UserDetailsProvider>
					</ThemeProvider>
				</BrowserRouter>
			);
		},
	],
	parameters: {
		i18n,
		viewMode: 'story',
		options: {
			storySort: {
				order: ['Introduction', 'Elements', 'Components', 'Layouts', 'Pages'],
			},
		},
		controls: {
			expanded: true,
			matchers: {
				color: /(background|color)$/i,
				date: /Date$/,
			},
		},
	},
	initialGlobals: {
		locale: 'en_US',
		locales: {
			en: 'English (US)',
			pt: 'Português (BR)',
		},
	},
};

export default preview;
