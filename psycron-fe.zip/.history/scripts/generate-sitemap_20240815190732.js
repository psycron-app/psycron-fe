/* eslint-disable no-console */
import { createWriteStream } from 'fs';
import { SitemapStream, streamToPromise } from 'sitemap';

// Defina suas rotas
const routes = [
	{ url: '/', changefreq: 'monthly', priority: 1.0 },
	{ url: '/sign-in', changefreq: 'monthly', priority: 0.7 },
	{ url: '/sign-up', changefreq: 'monthly', priority: 0.7 },
	// Adicione mais rotas conforme necessário
];

// Crie o fluxo para o arquivo sitemap.xml
const sitemapStream = new SitemapStream({ hostname: 'https://psycron.app' });
const writeStream = createWriteStream('./public/sitemap.xml');

// Adicione as rotas ao sitemap
routes.forEach(route => {
	sitemapStream.write(route);
});

sitemapStream.end();

// Escreva o sitemap no arquivo
streamToPromise(sitemapStream)
	.then(data => writeStream.write(data.toString()))
	.catch(err => {
		console.error('Erro ao gerar o sitemap:', err);
	});

console.log('Sitemap gerado com sucesso!');
