import { createContext } from 'react';
import { getTherapistLatestAvailability } from '@psycron/api/user';
import { useUserDetails } from '@psycron/context/user/details/UserDetailsContext';
import { useQuery } from '@tanstack/react-query';

import type {
	AvailabilityContextType,
	AvailabilityProviderProps,
} from './AvailabilityContext.types';

export const AvailabilityContext = createContext<
	AvailabilityContextType | undefined
>(undefined);

export const AvailabilityProvider = ({
	children,
}: AvailabilityProviderProps) => {
	const { therapistId } = useUserDetails();

	const { data, isLoading } = useQuery({
		queryKey: ['therapistAvailability', therapistId],
		queryFn: async () => getTherapistLatestAvailability(therapistId),
		enabled: !!therapistId,
		staleTime: 1000 * 60 * 5,
	});

	return (
		<AvailabilityContext.Provider
			value={{
				availabilityData: data,
				availabilityDataIsLoading: isLoading,
				isAvailabilityDatesEmpty: data?.isEmpty,
				firstDate: data?.firstDate,
				lastDate: data?.lastDate,
				totalPages: data?.totalPages,
			}}
		>
			{children}
		</AvailabilityContext.Provider>
	);
};

// dataFromSelectedDay,
// isDataFromSelectedDayLoading,
// hasNextPage,
// hasPreviousPage: false,
// goToPreviousWeek,
// goToNextWeek,
// lastAvailableDate,
// lastAvailableDateIdFromPagination,
// appointmentDetailsBySlotId,
// isAppointmentDetailsBySlotIdLoading,
