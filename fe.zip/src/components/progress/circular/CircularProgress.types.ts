export type IHovered = 'primary' | 'secondary';

export interface ICircularProgressProps {
  progress: number[];
}
