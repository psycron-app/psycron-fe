export interface IProgressProps {
    appointmentStart?: string;
    duration?: number;
    shouldProceed?: boolean;
    showLabel?: boolean;
    size?: number;
}
