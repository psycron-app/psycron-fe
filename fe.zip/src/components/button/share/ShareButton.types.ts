export interface IShareButton {
	shareWith?: string;
	textKey: string;
	titleKey: string;
	url?: string;
}
