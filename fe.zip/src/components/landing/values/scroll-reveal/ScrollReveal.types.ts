export interface IScrollRevealProps {
  text: string;
}
