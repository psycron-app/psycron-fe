import { addons, types } from '@storybook/addons';
import { useEffect, useState } from 'react';
import { API, useStorybookApi } from '@storybook/api';
import { AddonPanel } from '@storybook/components';
import React from 'react';

const ADDON_ID = 'my-addon';
const PANEL_ID = `${ADDON_ID}/panel`;

const MyPanel = () => {
  const api = useStorybookApi();
  const [stories, setStories] = useState([]);

  useEffect(() => {
    const storyList = api.getStories();
    setStories(Object.values(storyList).map((story) => story.id));
  }, [api]);

  return (
    <div>
      <h2>Stories List</h2>
      <ul>
        {stories.map((story) => (
          <li key={story}>{story}</li>
        ))}
      </ul>
    </div>
  );
};

addons.register(ADDON_ID, () => {
  addons.add(PANEL_ID, {
    type: types.PANEL,
    title: 'My Stories Addon',
    render: ({ active, key }) => (
      <AddonPanel active={active} key={key}>
        <MyPanel />
      </AddonPanel>
    ),
  });
});
