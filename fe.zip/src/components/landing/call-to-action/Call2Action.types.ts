import type { ReactNode } from 'react';

export interface ICall2ActionSection {
  bgColor?: string;
  c2Action: ReactNode;
  headingText: string;
  i18nextTrans: string;
}
