import { create } from '@storybook/theming/create';

export default create({
  base: 'light',
  brandTitle: 'Psycron',
  brandUrl: 'https://psycron.app',
  brandImage: 'src/assets/psycron-logo.svg',
  brandTarget: '_self',
  textColor: '#060B0E',
  appBorderRadius: 40,
});