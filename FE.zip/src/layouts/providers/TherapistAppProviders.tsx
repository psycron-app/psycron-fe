import type { FC } from 'react';
import { Outlet } from 'react-router-dom';

export const TherapistAppProviders: FC = () => {
	return <Outlet />;
};
