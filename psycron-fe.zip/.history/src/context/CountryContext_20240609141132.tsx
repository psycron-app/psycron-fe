import type { Dispatch, FC, ReactNode, SetStateAction } from 'react';
import { createContext, useEffect, useState } from 'react';
import countryList from '@psycron/assets/countries/countries.json';
import { IP_GEO_KEY, IP_GEO_URL } from '@psycron/utils/variables';

interface Country {
  code: string;
  dialCode: string;
  flag: string;
  name: string;
}

interface UserGeoLocationContextType {
  country: Country | null;
  setCountry: Dispatch<SetStateAction<Country | null>>;
}

export const CountryContext = createContext<
  UserGeoLocationContextType | undefined
>(undefined);

export const UserGeoLocationProvider: FC<{ children: ReactNode }> = ({ children }) => {
	const [country, setCountry] = useState<Country | null>(null);

	const fetchUserCountry = async () => {
		try {
			const res = await fetch(`${IP_GEO_URL}?apiKey=${IP_GEO_KEY}`);
			const data = await res.json();
			const userCountry = countryList.find(
				(c: Country) => c.dialCode === data.country_code
			);
			setCountry(userCountry || null);
		} catch (error) {
			console.log('errrrrrro====', error);
		}
	};

	useEffect(() => {
		fetchUserCountry();
	}, []);

	return (
		<CountryContext.Provider value={{ country, setCountry }}>
			{children}
		</CountryContext.Provider>
	);
};
