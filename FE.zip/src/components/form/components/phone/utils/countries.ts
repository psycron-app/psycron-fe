import type { Country } from 'react-phone-number-input';

const EU_COUNTRIES: Country[] = [
	'AT',
	'BE',
	'BG',
	'HR',
	'CY',
	'CZ',
	'DK',
	'EE',
	'FI',
	'FR',
	'DE',
	'GR',
	'HU',
	'IE',
	'IT',
	'LV',
	'LT',
	'LU',
	'MT',
	'NL',
	'PL',
	'PT',
	'RO',
	'SK',
	'SI',
	'ES',
	'SE',
];

export const ALLOWED_COUNTRIES: Country[] = ['BR', ...EU_COUNTRIES];
