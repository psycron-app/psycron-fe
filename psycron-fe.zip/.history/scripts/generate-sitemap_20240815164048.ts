import { writeFileSync } from 'fs';

import { DOMAIN, UNSUBSCRIBE } from '../src/pages/urls';
import publicRoutes from '../src/routes/PublicRoutes';

interface Route {
	children?: Route[];
	element: JSX.Element;
	index?: boolean;
	path?: string;
}

const languages = ['en', 'pt'];

const extractPaths = (routes: Route[], ignorePaths: string[]): string[] => {
	const paths: string[] = [];

	routes.forEach((route) => {
		if (route.path && !ignorePaths.includes(route.path)) {
			paths.push(route.path);
		}

		if (route.children) {
			route.children.forEach((child) => {
				if (child.path && !ignorePaths.includes(child.path)) {
					paths.push(`${route.path ? route.path : ''}/${child.path}`);
				} else if (child.index) {
					paths.push(route.path ? route.path : '');
				}
			});
		}
	});

	return paths;
};

const ignorePaths = [UNSUBSCRIBE];

const staticRoutes = extractPaths(publicRoutes, ignorePaths);

const routesWithLanguages = languages.flatMap((lang) =>
	staticRoutes.map((route) => `/${lang}${route}`)
);

const generateSitemapXML = (routes: string[], baseUrl: string): string => {
	const urlsetOpen =
		'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
	const urlsetClose = '</urlset>';

	const urls = routes
		.map((route) => {
			return `  <url>\n    <loc>${baseUrl}${route}</loc>\n    <changefreq>monthly</changefreq>\n    <priority>0.8</priority>\n  </url>`;
		})
		.join('\n');

	return `${urlsetOpen}${urls}\n${urlsetClose}`;
};

const sitemap = generateSitemapXML(routesWithLanguages, DOMAIN);

writeFileSync('./public/sitemap.xml', sitemap);
