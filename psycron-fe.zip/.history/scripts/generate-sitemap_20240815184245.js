'use strict';
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
	if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
		if (ar || !(i in from)) {
			if (!ar) ar = Array.prototype.slice.call(from, 0, i);
			ar[i] = from[i];
		}
	}
	return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, '__esModule', { value: true });
var sitemap_ts_1 = require('sitemap-ts');
var urls_1 = require('../src/pages/urls');
var PublicRoutes_1 = require('../src/routes/PublicRoutes');
var extractPaths = function (routes, basePath, ignorePaths) {
	if (basePath === void 0) { basePath = ''; }
	if (ignorePaths === void 0) { ignorePaths = []; }
	var paths = [];
	routes.forEach(function (route) {
		var fullPath = ''.concat(basePath, '/').concat(route.path || '').replace(/\/+/g, '/');
		if (route.index) {
			paths.push(basePath);
		}
		if (route.path && !ignorePaths.includes(route.path)) {
			paths.push(fullPath);
		}
		if (route.children) {
			paths.push.apply(paths, extractPaths(route.children, fullPath, ignorePaths));
		}
	});
	return paths;
};
var ignorePaths = [urls_1.UNSUBSCRIBE];
var routes = extractPaths(PublicRoutes_1.default, '', ignorePaths);
var uniqueRoutes = __spreadArray([], new Set(routes), true);
console.log('Rotas extraídas:', uniqueRoutes);
(0, sitemap_ts_1.default)({
	hostname: 'https://psycron.app',
	dynamicRoutes: uniqueRoutes,
	changefreq: 'monthly',
	priority: 0.8,
	outDir: './public',
	generateRobotsTxt: true,
	readable: true,
	basePath: '',
});
