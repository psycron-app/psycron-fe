import type { TooltipProps } from '@mui/material';

export interface PsycronTooltipProps extends TooltipProps {
	disabled: boolean;
}
