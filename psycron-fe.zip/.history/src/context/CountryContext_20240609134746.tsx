import type { Dispatch, FC, ReactNode, SetStateAction} from 'react';
import { createContext, useEffect, useState } from 'react';

interface Country {
  code: string;
  dialCode: string;
  flag: string;
  name: string;
}

interface UserGeoLocationContextType {
    country: Country | null;
    setCountry: Dispatch<SetStateAction<Country | null>>
}

export const CountryContext = createContext<UserGeoLocationContextType | undefined>(undefined)

export const UserGeoLocation: FC<{children: ReactNode}> = ({children}) => {
	const [country, setCountry] = useState<Country | null>(null);

	useEffect(() => {
		const getCountryFromLocale = () => {
			const locale = navigator.language || na
		}
		
	}, [])
}