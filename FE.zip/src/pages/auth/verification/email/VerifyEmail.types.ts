export type VerifyState = 'idle' | 'loading' | 'success' | 'error';
