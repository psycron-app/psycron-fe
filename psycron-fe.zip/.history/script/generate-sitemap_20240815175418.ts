import { writeFileSync } from 'fs';
import Sitemap from 'sitemap-ts';

import { UNSUBSCRIBE } from './src/pages/urls'; // Importa as rotas para ignorar
import publicRoutes from './src/routes/PublicRoutes'; // Ajuste o caminho conforme necessário

// Defina o tipo Route com base no que você está usando no react-router-dom
interface Route {
	children?: Route[];
	element: JSX.Element;
	index?: boolean;
	path?: string;
}

// Função para extrair todos os caminhos das rotas
const extractPaths = (
	routes: Route[],
	basePath = '',
	ignorePaths: string[] = []
): string[] => {
	const paths: string[] = [];

	routes.forEach((route) => {
		// Constrói o caminho completo
		const fullPath = `${basePath}/${route.path || ''}`.replace(/\/+/g, '/'); // Remove barras extras

		// Se for uma rota index, considera o caminho base
		if (route.index) {
			paths.push(basePath);
		}

		// Se houver um caminho, adiciona à lista (somente se não estiver na lista de ignorados)
		if (route.path && !ignorePaths.includes(route.path)) {
			paths.push(fullPath);
		}

		// Processa rotas filhas, se existirem
		if (route.children) {
			paths.push(...extractPaths(route.children, fullPath, ignorePaths));
		}
	});

	return paths;
};

// Lista de rotas para ignorar
const ignorePaths = [UNSUBSCRIBE];

// Extrai os caminhos das rotas públicas
const routes = extractPaths(publicRoutes, '', ignorePaths);

// Remove duplicatas caso existam
const uniqueRoutes = [...new Set(routes)];

console.log('Rotas extraídas:', uniqueRoutes);

// Base URL do seu site
const baseUrl = 'https://psycron.app';

// Crie uma instância do Sitemap
const sitemap = new Sitemap({
	baseUrl: baseUrl,
	urls: uniqueRoutes.map((route) => ({
		url: route,
		changefreq: 'monthly',
		priority: 0.8,
	})),
});

// Gera o sitemap.xml e salva no diretório público
const sitemapXml = sitemap.xml();
writeFileSync('./public/sitemap.xml', sitemapXml);

console.log('Sitemap gerado com sucesso!');
