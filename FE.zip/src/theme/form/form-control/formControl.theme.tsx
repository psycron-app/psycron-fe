import type { CSSObject } from '@mui/system';

const formControl = (): Record<string, CSSObject> => {
	return {
		root: {
			// margin: `${spacing.xs} ${spacing.xxs}`
		},
	};
};

export default formControl;
