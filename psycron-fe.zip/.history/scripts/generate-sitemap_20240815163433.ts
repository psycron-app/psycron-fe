import { generateSitemap } from 'react-sitemap-generator';
import { UNSUBSCRIBE } from '@psycron/pages/urls';
import publicRoutes from '@psycron/routes/PublicRoutes';

interface Route {
	children?: Route[];
	element: JSX.Element;
	index?: boolean;
	path: string;
}

const languages = ['en', 'pt'];

// Função para extrair os caminhos das rotas e suas crianças, com tipos fortes
const extractPaths = (routes: Route[], ignorePaths: string[]): string[] => {
	const paths: string[] = [];

	routes.forEach((route) => {
		// Ignorar caminhos específicos
		if (ignorePaths.includes(route.path)) {
			return;
		}

		// Adiciona a rota principal
		if (route.path) {
			paths.push(route.path);
		}

		// Adiciona as rotas filhas, se existirem e não forem ignoradas
		if (route.children) {
			route.children.forEach((child) => {
				if (!ignorePaths.includes(child.path)) {
					if (child.path) {
						paths.push(`${route.path}/${child.path}`);
					} else if (child.index) {
						paths.push(route.path);
					}
				}
			});
		}
	});

	return paths;
};

// Ignorar rotas específicas, como a UNSUBSCRIBE
const ignorePaths = [UNSUBSCRIBE];

// Extrai os caminhos das rotas públicas, ignorando as rotas configuradas
const staticRoutes = extractPaths(publicRoutes, ignorePaths);

// Cria as rotas com suporte a idiomas
const routesWithLanguages = languages.flatMap((lang) =>
	staticRoutes.map((route) => `/${lang}${route}`)
);

// Gere o sitemap
generateSitemap({
	url: 'https://psycron.app/', // URL base do seu site
	routes: routesWithLanguages, // Array de strings com as rotas geradas
	output: './public', // Caminho de saída do sitemap
});
