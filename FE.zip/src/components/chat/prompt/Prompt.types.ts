export interface IPromptProps {
	onSubmit: (text: string) => void;
}
