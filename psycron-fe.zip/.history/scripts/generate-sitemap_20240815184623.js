'use strict';
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
	if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
		if (ar || !(i in from)) {
			if (!ar) ar = Array.prototype.slice.call(from, 0, i);
			ar[i] = from[i];
		}
	}
	return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, '__esModule', { value: true });
var sitemap_ts_1 = require('sitemap-ts');
var urls_1 = require('../src/pages/urls');
var PublicRoutes_1 = require('../src/routes/PublicRoutes');
// Função para extrair todos os caminhos das rotas
var extractPaths = function (routes) {
	return routes.map(function (route) { return (route.index ? '/' : route.path || ''); });
};
// Lista de rotas para ignorar
var ignorePaths = [urls_1.UNSUBSCRIBE];
// Extrai os caminhos das rotas públicas
var routes = extractPaths(PublicRoutes_1.default).filter(function (route) { return !ignorePaths.includes(route); });
// Remove duplicatas caso existam
var uniqueRoutes = __spreadArray([], new Set(routes), true);
console.log('Rotas extraídas:', uniqueRoutes);
// Gera o sitemap usando a função Sitemap
(0, sitemap_ts_1.default)({
	hostname: 'https://psycron.app',
	dynamicRoutes: uniqueRoutes,
	changefreq: 'monthly',
	priority: 0.8,
	outDir: './public',
	generateRobotsTxt: true,
	readable: true,
});
console.log('Sitemap gerado com sucesso!');
