import { useWatch } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { Google } from '@psycron/components/icons';

import {
	StyledGoogleButton,
	StyledStyledGoogleButtonLabel,
} from './GoogleOAuthButton.styles';
import type { GoogleOAuthButtonProps } from './GoogleOAuthButton.types';
import { startGoogleOAuth } from './startGoogleOAuth';

export const GoogleOAuthButton = ({
	locale,
	disabled,
	intent,
	audience,
}: GoogleOAuthButtonProps) => {
	const { t } = useTranslation();

	const stayConnected = useWatch({ name: 'stayConnected' }) as
		| boolean
		| undefined;

	return (
		<StyledGoogleButton
			onClick={() =>
				startGoogleOAuth({
					stayConnected: Boolean(stayConnected),
					locale,
					intent,
					audience,
				})
			}
			disabled={disabled}
			fullWidth
			tertiary
			variant='outlined'
			size='large'
			aria-label={t('auth.continue-google')}
		>
			<Google />
			<StyledStyledGoogleButtonLabel>
				{t('auth.continue-google')}
			</StyledStyledGoogleButtonLabel>
		</StyledGoogleButton>
	);
};
