import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';
import viteCompression from 'vite-plugin-compression';

export default defineConfig({
	plugins: [
		react({
			jsxImportSource: '@emotion/react',
			babel: {
				plugins: [
					[
						'@emotion',
						{
							sourceMap: true,
							autoLabel: 'dev-only',
							labelFormat: '[local]',
							cssPropOptimization: true,
						},
					],
				],
			},
		}),
		viteCompression({
			algorithm: 'gzip',
		}),
	],
	resolve: {
		alias: {
			'@psycron': path.resolve(__dirname, './src'),
			'@mui/styled-engine': '@mui/styled-engine-sc',
		},
	},
	server: {
		host: true,
		port: 5173,
	},
});
